<?php $__env->startSection('title', 'Dashboard - Zerox Management'); ?>
<?php $__env->startSection('page_title', 'System Dashboard & Graphical Analytics'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    .stat-card-link {
        text-decoration: none;
        display: block;
        transition: transform 0.25s ease, box-shadow 0.25s ease;
        border-radius: 12px;
        overflow: hidden;
    }
    .stat-card-link:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 25px rgba(0, 0, 0, 0.18) !important;
    }
    .stat-card-body {
        padding: 1.25rem;
        color: #ffffff;
        position: relative;
    }
    .stat-card-footer {
        background: rgba(0, 0, 0, 0.15);
        padding: 0.5rem 1.25rem;
        color: rgba(255, 255, 255, 0.9);
        font-size: 0.8rem;
        font-weight: 600;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Colorful Interactive KPI Stat Cards Grid with Direct Links -->
<div class="row g-3 mb-4">
    <!-- Total Products Card -->
    <div class="col-md-4 col-lg-2">
        <a href="<?php echo e(route('admin.products.index')); ?>" class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #6366f1, #4f46e5);">
            <div class="stat-card-body d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 text-uppercase fw-bold" style="font-size: 0.7rem;">Total Products</span>
                    <h2 class="fw-bold text-white m-0 mt-1"><?php echo e($stats['total_products']); ?></h2>
                </div>
                <div>
                    <i class="bi bi-capsule fs-1 text-white opacity-75"></i>
                </div>
            </div>
            <div class="stat-card-footer">
                <span>Manage Catalog</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
            </div>
        </a>
    </div>

    <!-- Categories Card -->
    <div class="col-md-4 col-lg-2">
        <a href="<?php echo e(route('admin.categories.index')); ?>" class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #3b82f6, #2563eb);">
            <div class="stat-card-body d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 text-uppercase fw-bold" style="font-size: 0.7rem;">Categories</span>
                    <h2 class="fw-bold text-white m-0 mt-1"><?php echo e($stats['total_categories']); ?></h2>
                </div>
                <div>
                    <i class="bi bi-folder2-open fs-1 text-white opacity-75"></i>
                </div>
            </div>
            <div class="stat-card-footer">
                <span>Manage Categories</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
            </div>
        </a>
    </div>

    <!-- Scratch Codes Card -->
    <div class="col-md-4 col-lg-2">
        <a href="<?php echo e(route('admin.verifications.index')); ?>" class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #10b981, #059669);">
            <div class="stat-card-body d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 text-uppercase fw-bold" style="font-size: 0.7rem;">Scratch Codes</span>
                    <h2 class="fw-bold text-white m-0 mt-1"><?php echo e($stats['total_verifications']); ?></h2>
                </div>
                <div>
                    <i class="bi bi-qr-code-scan fs-1 text-white opacity-75"></i>
                </div>
            </div>
            <div class="stat-card-footer">
                <span>Manage Security Codes</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
            </div>
        </a>
    </div>

    <!-- Verified Scans Card -->
    <div class="col-md-4 col-lg-2">
        <a href="<?php echo e(route('admin.verifications.index')); ?>" class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
            <div class="stat-card-body d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 text-uppercase fw-bold" style="font-size: 0.7rem;">Verified Scans</span>
                    <h2 class="fw-bold text-white m-0 mt-1"><?php echo e($stats['verified_codes']); ?></h2>
                </div>
                <div>
                    <i class="bi bi-shield-check fs-1 text-white opacity-75"></i>
                </div>
            </div>
            <div class="stat-card-footer">
                <span>View Verified Logs</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
            </div>
        </a>
    </div>

    <!-- Subscribers Card -->
    <div class="col-md-4 col-lg-2">
        <a href="<?php echo e(route('admin.subscribers.index')); ?>" class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #ec4899, #db2777);">
            <div class="stat-card-body d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 text-uppercase fw-bold" style="font-size: 0.7rem;">Subscribers</span>
                    <h2 class="fw-bold text-white m-0 mt-1"><?php echo e($stats['total_subscribers']); ?></h2>
                </div>
                <div>
                    <i class="bi bi-envelope-check fs-1 text-white opacity-75"></i>
                </div>
            </div>
            <div class="stat-card-footer">
                <span>View Subscribers</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
            </div>
        </a>
    </div>

    <!-- System Users Card -->
    <div class="col-md-4 col-lg-2">
        <?php if(Auth::user() && Auth::user()->hasRole('admin')): ?>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #06b6d4, #0891b2);">
        <?php else: ?>
            <div class="stat-card-link shadow-sm" style="background: linear-gradient(135deg, #06b6d4, #0891b2);">
        <?php endif; ?>
            <div class="stat-card-body d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-white-50 text-uppercase fw-bold" style="font-size: 0.7rem;">System Users</span>
                    <h2 class="fw-bold text-white m-0 mt-1"><?php echo e($stats['total_users']); ?></h2>
                </div>
                <div>
                    <i class="bi bi-people fs-1 text-white opacity-75"></i>
                </div>
            </div>
            <div class="stat-card-footer">
                <span>Manage User Roles</span>
                <i class="bi bi-arrow-right-short fs-5"></i>
            </div>
        <?php if(Auth::user() && Auth::user()->hasRole('admin')): ?>
            </a>
        <?php else: ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Graphical Presentation Section (Chart.js) -->
<div class="row g-4 mb-4">
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm bg-white p-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-bar-chart-fill text-primary me-2"></i> Security Scratch Codes Distribution by Batch</h6>
            <div style="height: 260px;">
                <canvas id="batchChartCanvas"></canvas>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card border-0 shadow-sm bg-white p-4">
            <h6 class="fw-bold text-dark mb-3"><i class="bi bi-pie-chart-fill text-info me-2"></i> Products Distribution by Category</h6>
            <div style="height: 260px;">
                <canvas id="categoryChartCanvas"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-7">
        <div class="card border-0 shadow-sm bg-white p-4">
            <h5 class="fw-bold mb-3"><i class="bi bi-clock-history text-info me-2"></i> Recent Verification Checks</h5>
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Security Code</th>
                            <th>Product</th>
                            <th>Batch</th>
                            <th>Verified At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentVerifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><span class="badge bg-dark font-monospace"><?php echo e($ver->security_code); ?></span></td>
                                <td class="fw-bold"><?php echo e($ver->product->name ?? 'General'); ?></td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($ver->batch_number); ?></span></td>
                                <td class="small text-muted"><?php echo e($ver->verified_at ? $ver->verified_at->diffForHumans() : 'N/A'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="text-center text-muted">No verifications logged yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card border-0 shadow-sm bg-white p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold m-0"><i class="bi bi-plus-circle text-primary me-2"></i> Latest Products</h5>
                <a href="<?php echo e(route('admin.products.create')); ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus me-1"></i> Add New</a>
            </div>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item px-0 d-flex justify-content-between align-items-center">
                        <div>
                            <strong class="d-block text-dark"><?php echo e($p->name); ?></strong>
                            <small class="text-muted"><?php echo e($p->category->name ?? 'Category'); ?> | SKU: <?php echo e($p->sku); ?></small>
                        </div>
                        <a href="<?php echo e(route('admin.products.edit', $p->id)); ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-pencil"></i></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        // Chart 1: Bar Chart for Batch Security Codes
        const batchCtx = document.getElementById('batchChartCanvas').getContext('2d');
        new Chart(batchCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($batchLabels); ?>,
                datasets: [{
                    label: 'Security Codes Generated',
                    data: <?php echo json_encode($batchData); ?>,
                    backgroundColor: 'rgba(56, 189, 248, 0.7)',
                    borderColor: 'rgba(56, 189, 248, 1)',
                    borderWidth: 1,
                    borderRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });

        // Chart 2: Doughnut Chart for Category Products
        const catCtx = document.getElementById('categoryChartCanvas').getContext('2d');
        new Chart(catCtx, {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($catLabels); ?>,
                datasets: [{
                    data: <?php echo json_encode($catData); ?>,
                    backgroundColor: [
                        '#0284c7',
                        '#0d9488',
                        '#eab308',
                        '#8b5cf6',
                        '#ec4899'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\zzerox\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>