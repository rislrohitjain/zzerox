<?php $__env->startSection('title', 'Batch Generate Security Codes - Zerox Admin'); ?>
<?php $__env->startSection('page_title', 'Generate Security Scratch Codes'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm bg-white p-4" style="max-width: 600px;">
    <form action="<?php echo e(route('admin.verifications.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label fw-bold">Select Product</label>
            <select name="product_id" class="form-select" required>
                <option value="">Select Product...</option>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?> (SKU: <?php echo e($p->sku); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label fw-bold">Batch Number</label>
            <input type="text" name="batch_number" class="form-control" placeholder="e.g. ZX-2026-B9" required>
        </div>

        <div class="mb-4">
            <label class="form-label fw-bold">Number of Scratch Codes to Generate</label>
            <input type="number" name="count" class="form-control" value="10" min="1" max="100" required>
            <div class="form-text">Codes will be generated in ZX-XXXX-XXXX format and associated with the selected batch.</div>
        </div>

        <button type="submit" class="btn btn-primary px-4 me-2"><i class="bi bi-gear-fill me-1"></i> Generate Codes</button>
        <a href="<?php echo e(route('admin.verifications.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\zzerox\resources\views\admin\verifications\create.blade.php ENDPATH**/ ?>