<?php $__env->startSection('title', $product->name . ' | Zerox – Pharmaceuticals'); ?>
<?php $__env->startSection('meta_description', Str::limit(strip_tags($product->description), 160)); ?>

<?php $__env->startSection('content'); ?>
<section class="banner" style="min-height: 120px; background: #0f172a; color: #fff; padding: 40px 0;">
    <div class="container">
        <h1 style="font-size: 28px; font-weight: 700; color: #c9a227; margin-bottom: 5px;"><?php echo e($product->name); ?></h1>
        <p style="color: #aaa; margin: 0;">SKU: <?php echo e($product->sku); ?> | Category: <?php echo e($product->category->name); ?></p>
    </div>
</section>

<div class="container" style="padding: 50px 15px;">
    <div class="row">
        <!-- Main Image & Interactive Photo Gallery Zoom Effect -->
        <div class="col-md-5 col-xs-12">
            <div style="background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 20px; text-align: center;">
                <div class="zoom-effect-container">
                    <a id="mainImageLightboxLink" href="<?php echo e(asset($product->image_path ?? 'img/welcome-image.png')); ?>" data-lightbox="product-gallery" data-title="<?php echo e($product->name); ?>">
                        <img id="mainProductImage" class="zoom-effect-img" src="<?php echo e(asset($product->image_path ?? 'img/welcome-image.png')); ?>" alt="<?php echo e($product->name); ?>" style="max-width: 100%; max-height: 350px; object-fit: contain; border-radius: 4px;">
                        <div class="zoom-overlay-icon"><i class="bi bi-search font-weight-bold"></i></div>
                    </a>
                </div>

                <!-- Product Gallery Thumbnails with Zoom Preview -->
                <?php if(isset($product->images) && count($product->images) > 0): ?>
                    <div class="product-gallery-thumbs" style="justify-content: center; margin-top: 20px;">
                        <a href="<?php echo e(asset($product->image_path ?? 'img/welcome-image.png')); ?>" data-lightbox="product-gallery" data-title="<?php echo e($product->name); ?> - Main Image" style="display: inline-block;">
                            <img src="<?php echo e(asset($product->image_path ?? 'img/welcome-image.png')); ?>" class="product-gallery-thumb active" onclick="switchMainImage(this.src, this); return false;">
                        </a>
                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $gImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(asset($gImg->image_path)); ?>" data-lightbox="product-gallery" data-title="<?php echo e($product->name); ?> - Gallery View <?php echo e($index + 1); ?>" style="display: inline-block;">
                                <img src="<?php echo e(asset($gImg->image_path)); ?>" class="product-gallery-thumb" onclick="switchMainImage(this.src, this); return false;">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
                <small class="text-muted d-block mt-2" style="font-size: 12px;"><i class="bi bi-zoom-in me-1"></i> Click image or thumbnails to open full-screen lightbox zoom</small>
            </div>
        </div>

        <!-- Product Specs & Summary -->
        <div class="col-md-7 col-xs-12">
            <h2 style="font-size: 26px; font-weight: 700; color: #111; margin-top: 0;"><?php echo e($product->name); ?></h2>
            <div style="display: flex; gap: 15px; margin: 15px 0;">
                <span style="background: #f0f4f8; color: #333; padding: 5px 12px; border-radius: 4px; font-size: 14px; font-weight: 600;">Dosage: <?php echo e($product->dosage_form ?? 'N/A'); ?></span>
                <span style="background: #f0f4f8; color: #333; padding: 5px 12px; border-radius: 4px; font-size: 14px; font-weight: 600;">Pack Size: <?php echo e($product->pack_size ?? 'N/A'); ?></span>
            </div>

            <div style="font-size: 15px; line-height: 1.6; color: #555; margin-bottom: 25px;">
                <?php echo $product->description; ?>

            </div>

            <div style="background: #fff8e6; border: 1px solid #ffeeba; border-radius: 6px; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong style="color: #856404; display: block;">Verify Scratch Code</strong>
                    <span style="font-size: 13px; color: #856404;">Check authenticity label on packaging box</span>
                </div>
                <a href="<?php echo e(route('authenticity')); ?>" style="background: #c9a227; color: #000; padding: 8px 18px; font-weight: 700; border-radius: 4px; text-decoration: none; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.04)';" onmouseout="this.style.transform='scale(1)';">Verify Code</a>
            </div>
        </div>
    </div>

    <!-- Specifications Tabs -->
    <div style="margin-top: 50px;">
        <div style="border-bottom: 2px solid #eee; display: flex; gap: 20px; margin-bottom: 25px;">
            <button class="tab-btn active" onclick="openSpecTab(event, 'tab-chemical')" style="background: none; border: none; padding: 10px 20px; font-size: 16px; font-weight: 700; color: #c9a227; border-bottom: 3px solid #c9a227; cursor: pointer;">Chemical Characteristics</button>
            <button class="tab-btn" onclick="openSpecTab(event, 'tab-side-effects')" style="background: none; border: none; padding: 10px 20px; font-size: 16px; font-weight: 700; color: #666; cursor: pointer;">Side Effects</button>
            <button class="tab-btn" onclick="openSpecTab(event, 'tab-administration')" style="background: none; border: none; padding: 10px 20px; font-size: 16px; font-weight: 700; color: #666; cursor: pointer;">Administration & Uses</button>
        </div>

        <div id="tab-chemical" class="tab-content-item animated-fade-in" style="display: block;">
            <div style="background: #f8f9fa; padding: 20px; border-radius: 6px; font-family: monospace; white-space: pre-wrap; color: #333;"><?php echo $product->chemical_characteristics; ?></div>
        </div>

        <div id="tab-side-effects" class="tab-content-item animated-fade-in" style="display: none;">
            <div style="background: #f8f9fa; padding: 20px; border-radius: 6px; color: #444;"><?php echo $product->side_effects; ?></div>
        </div>

        <div id="tab-administration" class="tab-content-item animated-fade-in" style="display: none;">
            <div style="background: #f8f9fa; padding: 20px; border-radius: 6px; color: #444;"><?php echo $product->administration_uses; ?></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    function switchMainImage(src, element) {
        document.getElementById('mainProductImage').src = src;
        document.getElementById('mainImageLightboxLink').href = src;
        document.querySelectorAll('.product-gallery-thumb').forEach(thumb => thumb.classList.remove('active'));
        element.classList.add('active');
    }

    function openSpecTab(evt, tabName) {
        document.querySelectorAll('.tab-content-item').forEach(item => item.style.display = 'none');
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.style.color = '#666';
            btn.style.borderBottom = 'none';
        });
        document.getElementById(tabName).style.display = 'block';
        evt.currentTarget.style.color = '#c9a227';
        evt.currentTarget.style.borderBottom = '3px solid #c9a227';
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\zzerox\resources\views\products\show.blade.php ENDPATH**/ ?>