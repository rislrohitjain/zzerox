<?php $__env->startSection('title', 'Manage Subscribers - Zerox Admin'); ?>
<?php $__env->startSection('page_title', 'Newsletter Subscribers Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm bg-white p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="fw-bold m-0"><i class="bi bi-envelope-check text-primary me-2"></i> Subscribers (<?php echo e($subscribers->total()); ?>)</h5>
        <div>
            <?php if(request()->get('trashed') == '1'): ?>
                <a href="<?php echo e(route('admin.subscribers.index')); ?>" class="btn btn-sm btn-outline-secondary">View Active Subscribers</a>
            <?php else: ?>
                <a href="<?php echo e(route('admin.subscribers.index', ['trashed' => 1])); ?>" class="btn btn-sm btn-outline-danger">View Soft-Deleted Subscribers</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Interactive Search Bar -->
    <div class="row g-2 mb-3 p-3 bg-light rounded border">
        <div class="col-md-9">
            <div class="input-group">
                <span class="input-group-text bg-white"><i class="bi bi-search text-muted"></i></span>
                <input type="text" id="adminSubscriberSearch" class="form-control" placeholder="Search by Subscriber Email Address or IP...">
            </div>
        </div>
        <div class="col-md-3 text-end d-flex align-items-center justify-content-end">
            <span class="badge bg-white text-dark border py-2 px-3"><i class="bi bi-funnel text-primary me-1"></i> Live Filter</span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle border" id="adminSubscribersTable">
            <thead class="table-light">
                <tr>
                    <th>Email Address</th>
                    <th>IP Address</th>
                    <th>Subscribed At</th>
                    <th>Status</th>
                    <th class="text-end">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="fw-bold text-dark"><i class="bi bi-envelope text-info me-2"></i><?php echo e($sub->email); ?></td>
                        <td><code class="text-muted"><?php echo e($sub->ip_address ?? 'N/A'); ?></code></td>
                        <td class="small text-muted"><?php echo e($sub->subscribed_at ? $sub->subscribed_at->format('Y-m-d H:i') : $sub->created_at->format('Y-m-d H:i')); ?></td>
                        <td>
                            <?php if($sub->trashed()): ?>
                                <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25">Soft Deleted</span>
                            <?php elseif($sub->is_active): ?>
                                <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-25">Subscribed</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-end">
                            <?php if($sub->trashed()): ?>
                                <form action="<?php echo e(route('admin.subscribers.restore', $sub->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-success me-1"><i class="bi bi-arrow-counterclockwise"></i> Restore</button>
                                </form>
                                <form action="<?php echo e(route('admin.subscribers.forceDelete', $sub->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Permanently remove subscriber?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"><i class="bi bi-x-circle"></i> Permanent Delete</button>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('admin.subscribers.destroy', $sub->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Soft delete this subscriber?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Soft Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="text-center text-muted py-4">No subscribers found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($subscribers->links('pagination::bootstrap-4')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchInput = document.getElementById('adminSubscriberSearch');
        const rows = document.querySelectorAll('#adminSubscribersTable tbody tr');

        if (searchInput) {
            searchInput.addEventListener('keyup', function() {
                const query = searchInput.value.toLowerCase().trim();
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = (!query || text.includes(query)) ? '' : 'none';
                });
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\zzerox\resources\views\admin\subscribers\index.blade.php ENDPATH**/ ?>