<?php $__env->startSection('title', 'Routes & Database Inspector - Zerox Admin'); ?>
<?php $__env->startSection('page_title', 'System Routes & Database Inspector'); ?>

<?php $__env->startSection('content'); ?>
<!-- DB Overview Metric Badges -->
<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold" style="font-size: 0.7rem;">Database Host</span>
                    <h5 class="fw-bold text-primary m-0 font-monospace"><?php echo e($dbInfo['host']); ?>:<?php echo e($dbInfo['port']); ?></h5>
                </div>
                <div class="p-2 bg-primary bg-opacity-10 text-primary rounded">
                    <i class="bi bi-hdd-rack fs-4"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold" style="font-size: 0.7rem;">Active Database</span>
                    <h5 class="fw-bold text-success m-0 font-monospace"><?php echo e($dbInfo['database']); ?></h5>
                </div>
                <div class="p-2 bg-success bg-opacity-10 text-success rounded">
                    <i class="bi bi-database fs-4"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold" style="font-size: 0.7rem;">DB Tables Count</span>
                    <h5 class="fw-bold text-dark m-0"><?php echo e($dbInfo['table_count']); ?> Tables</h5>
                </div>
                <div class="p-2 bg-info bg-opacity-10 text-info rounded">
                    <i class="bi bi-table fs-4"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-3">
        <div class="card border-0 shadow-sm p-3 bg-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <span class="text-muted small text-uppercase fw-bold" style="font-size: 0.7rem;">Total Application Routes</span>
                    <h5 class="fw-bold text-warning text-dark m-0"><?php echo e(count($routes)); ?> Registered Routes</h5>
                </div>
                <div class="p-2 bg-warning bg-opacity-10 text-warning rounded">
                    <i class="bi bi-signpost-split fs-4"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Main Tabs Card -->
<div class="card border-0 shadow-sm bg-white p-4">
    <ul class="nav nav-tabs border-bottom mb-4" id="inspectorTabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active fw-bold" id="routes-tab" data-bs-toggle="tab" data-bs-target="#routes-pane" type="button" role="tab"><i class="bi bi-signpost-split text-primary me-2"></i> Application Routes List (<?php echo e(count($routes)); ?>)</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link fw-bold" id="database-tab" data-bs-toggle="tab" data-bs-target="#database-pane" type="button" role="tab"><i class="bi bi-database-fill-gear text-success me-2"></i> Database Tables Inspector (<?php echo e($dbInfo['table_count']); ?>)</button>
        </li>
    </ul>

    <div class="tab-content" id="inspectorTabsContent">
        <!-- Routes Explorer Pane -->
        <div class="tab-pane fade show active" id="routes-pane" role="tabpanel">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <input type="text" id="routeSearchInput" class="form-control w-50" placeholder="🔍 Search routes by URI, Name, or Controller Action...">
                <span class="badge bg-light text-dark border"><i class="bi bi-filter me-1"></i> Live Filter</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle border" id="routesTable">
                    <thead class="table-light">
                        <tr>
                            <th style="width: 130px;">HTTP Method</th>
                            <th>URI Path</th>
                            <th>Route Name</th>
                            <th>Controller / Action</th>
                            <th>Middleware</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if(str_contains($r['methods'], 'GET')): ?>
                                        <span class="badge bg-primary">GET</span>
                                    <?php elseif(str_contains($r['methods'], 'POST')): ?>
                                        <span class="badge bg-success">POST</span>
                                    <?php elseif(str_contains($r['methods'], 'PUT')): ?>
                                        <span class="badge bg-warning text-dark">PUT</span>
                                    <?php elseif(str_contains($r['methods'], 'DELETE')): ?>
                                        <span class="badge bg-danger">DELETE</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($r['methods']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(url($r['uri'])); ?>" target="_blank" class="fw-bold text-dark font-monospace text-decoration-none">
                                        /<?php echo e(ltrim($r['uri'], '/')); ?> <i class="bi bi-box-arrow-up-right small text-muted ms-1"></i>
                                    </a>
                                </td>
                                <td>
                                    <?php if($r['name'] !== '-'): ?>
                                        <span class="badge bg-light text-primary border font-monospace"><?php echo e($r['name']); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted small">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="small text-muted font-monospace"><?php echo e(Str::replace('App\\Http\\Controllers\\', '', $r['action'])); ?></td>
                                <td class="small"><span class="badge bg-light text-dark border"><?php echo e($r['middleware'] ?: 'web'); ?></span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Database Inspector Pane -->
        <div class="tab-pane fade" id="database-pane" role="tabpanel">
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Table Name</th>
                            <th>Storage Engine</th>
                            <th>Total Records (Rows)</th>
                            <th>Data Size (MB)</th>
                            <th>Collation</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $dbTables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-bold font-monospace text-primary"><i class="bi bi-table me-2 text-secondary"></i> <?php echo e($tbl['name']); ?></td>
                                <td><span class="badge bg-light text-dark border"><?php echo e($tbl['engine']); ?></span></td>
                                <td class="fw-bold text-dark"><?php echo e(number_format($tbl['rows'])); ?></td>
                                <td class="font-monospace"><?php echo e($tbl['data_size_mb']); ?> MB</td>
                                <td class="small text-muted"><?php echo e($tbl['collation']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="5" class="text-center text-muted">No database tables retrieved.</td></tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="table-light">
                        <tr class="fw-bold">
                            <td>Total (<?php echo e(count($dbTables)); ?> Tables)</td>
                            <td>-</td>
                            <td><?php echo e(number_format($dbInfo['total_rows'])); ?> Total Rows</td>
                            <td><?php echo e(number_format($dbInfo['total_size_mb'], 2)); ?> MB Total Size</td>
                            <td>-</td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchInput = document.getElementById('routeSearchInput');
        const rows = document.querySelectorAll('#routesTable tbody tr');

        if (searchInput) {
            searchInput.addEventListener('keyup', function() {
                const term = searchInput.value.toLowerCase();
                rows.forEach(row => {
                    const text = row.textContent.toLowerCase();
                    row.style.display = text.includes(term) ? '' : 'none';
                });
            });
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\inetpub\wwwroot\zzerox\resources\views\admin\routes\index.blade.php ENDPATH**/ ?>